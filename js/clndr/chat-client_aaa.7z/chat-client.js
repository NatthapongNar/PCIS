angular.module("chat-client", [
        "ui.bootstrap"
    ])
    .constant("uiChatClientConfig", {
        permission: ['57251', '56225', '58141', '56679', '58106', '59016', '58385', '57160']
    })
    .factory("socket", function ($rootScope) {
        var socket = io.connect("http://tc001pcis1p", {path: '/node/pcischat/socket.io', "forceNew": true});
        //var socket = io.connect("http://localhost:1337", {"forceNew": true});
        return {
            on: function (eventName, callback) {
                socket.on(eventName, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        callback.apply(socket, args);
                    });
                });
            },
            emit: function (eventName, data, callback) {
                socket.emit(eventName, data, function () {
                    var args = arguments;
                    $rootScope.$apply(function () {
                        if (callback) {
                            callback.apply(socket, args);
                        }
                    });
                });
            }
        };
    })
    .factory("helper", function ($q, $http, $filter) {
        var fn = {};
        var link = "http://172.17.9.94/pcisservices/PCISService.svc/";

        fn.servicesMethod = {
            getChatUser: "GetChatUser",
            getChatHistory: "GetChatHistory",
            getListChatUser: "GetListChatUser",
            insertChatHistory: "InsertChatHistory",
            updateChatHistory: "UpdateChatHistory",
            deleteChatHistory: "DeleteChatHistory",
            getChatRecentMessage: "GetChatRecentMessage"
        };

        fn.formatDateTime = {
            formatToServer: "yyyy-MM-dd HH:mm:ss.fff",
            formatNormal: "dd/MM/yyyy HH:mm:ss",
            formatForChat: "dd/MM/yyyy AT HH:mm"
        };

        fn.md5 = function (value) {
            return CryptoJS.MD5(value.toString()).toString();
        };

        fn.convertDateFormat = function (date, format) {
            return $filter("date")(new Date(date), format);
        };

        fn.whereObject = function (objData, objSearch) {
            return $filter("filter")(objData, objSearch, true);
        };

        fn.executeServices = function (servicesMethod, objParam) {
            var deferred = $q.defer();

            var url = link + servicesMethod + "?callback=JSON_CALLBACK";

            var config = {params: objParam};

            $http.jsonp(url, config).then(function (resp) {
                deferred.resolve(resp);
            }, function (error) {
                deferred.reject(error);
            });

            return deferred.promise;
        };

        return fn;
    })
    .directive("enterSubmit", function () {
        return {
            restrict: "A",
            link: function (scope, elem, attrs) {
                elem.bind("keydown", function (event) {
                    var code = event.keyCode || event.which;
                    if (code === 13 && !event.shiftKey) {
                        event.preventDefault();
                        scope.$apply(attrs.enterSubmit);
                    }
                });
            }
        };
    })
    .directive("onLastRepeat", function () {
        return function (scope, elem, attrs) {
            if (scope.$last)
                setTimeout(function () {
                    scope.$emit(attrs.onLastRepeat, elem, attrs);
                }, 1);
        }
    })
    .directive("waves", function () {
        return {
            restrict: "A",
            scope: {
                wavesEffect: "="
            },
            link: function (scope, elem, attrs) {
                if (angular.isArray(scope.wavesEffect)) {
                    angular.forEach(scope.wavesEffect, function (item) {
                        elem.addClass(item);
                    });
                }
                else {
                    elem.addClass(scope.wavesEffect);
                }
                Waves.displayEffect();
            }
        };
    })
    .directive('focus', function ($timeout) {
        return {
            scope: {
                trigger: '=focus'
            },
            link: function (scope, element) {
                scope.$watch('trigger', function (value) {
                    if (value === true) {
                        $timeout(function () {
                            element[0].focus();
                        });
                    }
                });
            }
        };
    })
    .directive("scrollLoadMore", function () {
        return {
            scope: {
                scrollLoadMore: "&"
            },
            link: function (scope, elem, attrs) {
                elem.bind("scroll", function () {
                    var raw = elem[0];
                    var scrollTo = attrs.scrollTo;

                    switch (scrollTo.toLowerCase()) {
                        case "bottom":
                            if (raw.scrollTop + raw.offsetHeight + 5 >= raw.scrollHeight)
                                if (angular.isFunction(scope.scrollLoadMore)) {
                                    scope.$apply(scope.scrollLoadMore());
                                }
                        case "top":
                            break;
                    }
                });
            }
        };
    })
    .directive("uiChatClient", function (uiChatClientConfig, socket, helper, $q, $filter, $log, $uibModal) {

        var pathArray = window.location.pathname.split('/'), newPathname = window.location.protocol + "//" + window.location.host;
        for (var i = 0; i < (pathArray.length - 1); i++) {
            newPathname += pathArray[i];
            newPathname += "/";
        }

        var option = '';
        var pathFixed = window.location.protocol + "//" + window.location.host + '/pcis/';
        if (pathArray[1] == 'pcis')
            option = 'js/clndr/';
        //else if ($('body').is('.calendar'))
        else
            pathFixed = "";

        return {
            restrict: "A",
            templateUrl: pathFixed + option + "chat-client-template/chat-client-template.html",
            scope: {
                uiChatClient: "=",
                directChatTo: "="
            },
            link: function (scope, elem, attrs) {

                ion.sound({
                    sounds: [
                        {name: "beer_can_opening"},
                        {name: "bell_ring"},
                        {name: "branch_break"},
                        {name: "button_click"},
                        {name: "button_click_on"},
                        {name: "button_push"},
                        {name: "button_tiny"},
                        {name: "camera_flashing"}
                    ],
                    path: pathFixed + option + "sounds/",
                    preload: true,
                    multiplay: true
                });

                var modalIsOpen = false;
                scope.userlimit = 10;
                scope.imgPath = "../../img/announcement_icon.png";
                scope.nowdate = ("0" + new Date().getDate().toString()).slice(-2);
                scope.dialogPosition = "pull-right";
                scope.ownuser = null;
                scope.unReadMessage = [];
                scope.chatusers = [];
                scope.chatuserslist = [];
                scope.onlineUser = [];
                scope.chatRoomData = [];
                scope.defaultChecked = null;
                scope.currentChatInformation = null;
                scope.uriKpi = "";
                scope.uriCalendar = "";
                scope.data = {
                    from: null,
                    to: null,
                    message: null,
                    sendtime: null
                };
                scope.showbutton = {
                    btn_calendar: $('body').is('.calendar'),
                    btn_kpi: $("[data-page=kpi]")[0] ? true : false,
                    btn_chat: "",
                    btn_boardcast: "",
                    btn_notification: ""
                };

                function getLinkCalendar() {
                    var uri = "";

                    if (!scope.showbutton.btn_calendar) {

                    }

                    return uri;
                }

                function getLinkKPI() {
                    var uri = "";
                    if (!scope.showbutton.btn_kpi && scope.directChatTo) {
                        if (in_array(scope.data.from, uiChatClientConfig.permission))
                            uri = 'http://tc001pcis1p:8099/pcis/index.php/report/gridDataList?rel=' + scope.data.from + '&relsub=' + scope.directChatTo.toString() + '&editor=' + helper.md5(true) + '&permission=' + helper.md5(true);
                        else
                            uri = 'http://tc001pcis1p:8099/pcis/index.php/report/gridDataList?rel=' + scope.data.from + '&relsub=' + scope.directChatTo.toString() + '&editor=' + helper.md5(false) + '&permission=' + helper.md5(false);

                        function in_array(needle, haystack, argStrict) {

                            var key = '', strict = !!argStrict;

                            if (strict) {
                                for (key in haystack) {
                                    if (haystack[key] === needle) {
                                        return true;
                                    }
                                }
                            } else {
                                for (key in haystack) {
                                    if (haystack[key] == needle) {
                                        return true;
                                    }
                                }
                            }

                            return false;
                        }
                    }
                    return uri;
                }

                if ($('body').is('.metro'))
                    scope.imgPath = pathFixed + 'img/announcement_icon.png';
                else if ($('body').is('.calendar'))
                    scope.imgPath = 'images/announcement_icon.png';

                if (attrs.chatDialogPosition) {
                    var position = attrs.chatDialogPosition;
                    switch (position.toLowerCase()) {
                        case "left":
                            scope.dialogPosition = "pull-left";
                            break;
                        case "right":
                            scope.dialogPosition = "pull-right";
                            break;
                    }
                }

                scope.$watch("uiChatClient", function (n, o) {
                    if (n) {
                        socket.emit("register:online", {
                            username: n.toString()
                        });
                        iniChat(n.toString());
                    }
                });

                scope.$watch("directChatTo", function (n, o) {
                    if (n && o) {
                        scope.uriKpi = getLinkKPI();
                        scope.uriCalendar = getLinkCalendar();
                    }
                });

                function iniChat(username) {
                    scope.data.from = username;
                    scope.getChatUser(username);
                    scope.getChatRecentMessage(username);
                    scope.getListChatUser(username);

                    if ($("#" + attrs.directChatClick)) {
                        var directChatUserObj = $("#" + attrs.directChatClick);
                        directChatUserObj.addClass("direct-chatuser");
                        directChatUserObj.click(function (e) {
                            //var directEmpCode = $("[direct-chat-to]").attr("direct-chat-to");
                            var directEmpCode = scope.directChatTo.toString();
                            if (directEmpCode) {
                                if (directEmpCode == scope.data.from) {
                                    scope.openChatDialog("new");
                                }
                                else {
                                    var item = whereObject(scope.chatuserslist, {EmployeeCode: directEmpCode});
                                    if (item.length > 0) {
                                        scope.openChatDialog(item[0]);
                                    }
                                    else {
                                        var item = whereObject(scope.chatusers, {EmployeeCode: directEmpCode});
                                        scope.defaultChecked = item[0];
                                        scope.newChatUser.checked = item[0];
                                        scope.txtSearchUsers = directEmpCode;
                                        scope.openChatDialog("new");
                                    }
                                }
                            }
                        });
                    }
                }

                scope.getChatRecentMessage = function (username, showtoast) {
                    helper.executeServices(helper.servicesMethod.getChatRecentMessage, {OwnUser: username}).then(function (resp) {
                        var data = resp.data.Data;
                        angular.copy(data, scope.unReadMessage);
                        if (showtoast) {
                            Snarl.addNotification({
                                title: showtoast.from,
                                text: showtoast.message
                            });
                        }
                    });
                };

                scope.getChatUser = function (username) {
                    helper.executeServices(helper.servicesMethod.getChatUser).then(function (resp) {
                        var data = resp.data.Data;
                        var index = data.indexOf(whereObject(data, {EmployeeCode: username})[0]);
                        scope.ownuser = data.splice(index, 1)[0];
                        angular.copy(data, scope.chatusers);
                    });
                };

                scope.getListChatUser = function (username) {
                    helper.executeServices(helper.servicesMethod.getListChatUser, {Chat_From: username}).then(function (resp) {
                        var data = resp.data.Data;
                        angular.copy(data, scope.chatuserslist);
                    });
                };

                scope.getChatRoomHistory = function () {
                    helper.executeServices(helper.servicesMethod.getChatHistory, {
                        Chat_From: scope.data.to,
                        Chat_To: scope.data.from
                    }).then(function (resp) {
                        var data = resp.data.Data;

                        var subItem = {};
                        subItem["roomName"] = scope.data.to;
                        subItem["roomData"] = data;

                        var exitData = helper.whereObject(scope.chatRoomData, {"roomName": scope.data.to})[0];
                        var index = scope.chatRoomData.indexOf(exitData);

                        if (index >= 0) {
                            angular.copy(subItem, scope.chatRoomData[index]);
                        }
                        else {
                            scope.chatRoomData.push(subItem);
                        }
                    });
                };

                scope.openChatDialog = function (value) {
                    modalIsOpen = true;

                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'myModalContent.html',
                        size: "lg",
                        scope: scope
                    });

                    iniChatHistory(value);

                    modalInstance.result.then(function (resp) {
                        modalIsOpen = false;
                    }, function () {
                        scope.userlimit = 10;
                        modalIsOpen = false;
                        scope.isOpenSearch = false;
                        scope.currentChatInformation = null;
                        scope.txtSearchUsers = "";
                        scope.defaultChecked = null;
                    });
                };

                scope.checkOnline = function (items) {
                    return whereObject(scope.onlineUser, items.EmployeeCode).length > 0;
                };

                scope.formatChatDateTime = function (datetime) {
                    return helper.convertDateFormat(datetime, helper.formatDateTime.formatForChat).toLowerCase();
                };

                scope.loadMoreUser = function () {
                    if (scope.userlimit < scope.chatusers.length)
                        scope.userlimit += 10;
                };

                function whereObject(obj, coditions) {
                    return helper.whereObject(obj, coditions);
                }

                function addOnlineUser(data) {
                    scope.onlineUser = $.map(data, function (value) {
                        return value.userName;
                    });
                }

                function sendUpdateStatusReadMessage(data) {
                    var objData = $.extend({}, data);
                    objData.isReadMessage = true;
                    objData.to = data.from;
                    objData.from = scope.data.from;
                    socket.emit("chat:to", objData);
                }

                socket.on("register:online", function (data) {
                    addOnlineUser(data.clients);
                });

                socket.on("disconnect", function (data) {
                    addOnlineUser(data);
                    $log.log(data);
                    //ion.sound.play("bell_ring");
                });

                socket.on("chat:to", function (data) {
                    if (modalIsOpen) {
                        if (scope.currentChatInformation && !scope.isOpenSearch) {
                            if (scope.currentChatInformation.EmployeeCode == data.from) {

                                if (!data.isReadMessage) {
                                    helper.executeServices(helper.servicesMethod.updateChatHistory, {
                                            Chat_From: data.from,
                                            Chat_To: data.to,
                                            Chat_Status: 'R'
                                        })
                                        .then(function (resp) {
                                            sendUpdateStatusReadMessage(data);
                                            scope.getListChatUser(data.to);
                                            scope.getChatRoomHistory();
                                        });
                                }
                                else {
                                    scope.getListChatUser(data.to);
                                    scope.getChatRoomHistory();
                                }
                            }
                            else {
                                scope.getChatRecentMessage(data.to);
                                scope.getListChatUser(data.to);
                            }
                        }
                        else {
                            scope.getChatRecentMessage(data.to);
                            scope.getListChatUser(data.to);
                        }
                    }
                    else {
                        scope.getChatRecentMessage(data.to, data);
                    }

                    //ion.sound.play("button_tiny");
                });

                socket.on("chat:reload", function (data) {
                });

                socket.on("chat:toTyping", function (data) {
                    $log.log(data);
                });

                socket.on("broadcast:to", function (data) {
                    $log.log(data);
                });

                socket.on("broadcast:all", function (data) {
                    $log.log(data);
                });


                /*------------------ Modal Popup ---------------------------*/
                scope.newChatUser = {};
                scope.isOpenSearch = false;
                //scope.data.from = scope.ownuser.EmployeeCode;

                scope.newChat = function () {
                    scope.isOpenSearch = !scope.isOpenSearch;
                    scope.newChatUser.checked = scope.defaultChecked ? scope.defaultChecked : false;

                    if (!scope.isOpenSearch && !scope.currentChatInformation) {
                        if (scope.chatuserslist.length > 0) {
                            setDefaultUserChatSelection();
                            scope.select(scope.currentChatInformation);
                        }
                        else {
                            scope.isOpenSearch = true;
                        }
                    }
                    else if (!scope.isOpenSearch && scope.currentChatInformation) {
                        scope.select(scope.currentChatInformation);
                    }
                };

                scope.isOnline = function (items) {
                    return scope.checkOnline(items);
                };

                scope.isActive = function (items) {
                    return scope.data.to === items.EmployeeCode;
                };

                scope.select = function (items) {
                    doUpdateChatHistory(items);
                };

                scope.sendMessage = function (message) {

                    if (message) {

                        if (scope.isOpenSearch && !scope.newChatUser.checked)
                            return false;

                        if (scope.isOpenSearch) {
                            scope.currentChatInformation = scope.newChatUser.checked;
                            scope.data.to = scope.currentChatInformation.EmployeeCode;
                        }

                        var date = new Date();
                        var servertime = helper.convertDateFormat(date, helper.formatDateTime.formatToServer);

                        scope.data.message = message;
                        scope.data.sendtime = helper.convertDateFormat(date, helper.formatDateTime.formatForChat).toLowerCase();

                        helper.executeServices(helper.servicesMethod.insertChatHistory,
                            {
                                Chat_From: scope.data.from,
                                Chat_To: scope.data.to,
                                Chat_Message: scope.data.message,
                                Chat_DateTime: servertime,
                                Chat_Type: "P",
                                Chat_Room: null,
                                Chat_Status: "U",
                                Chat_Active: true
                            }
                        ).then(function (resp) {
                            var data = resp.data.Data;

                            socket.emit("chat:to", scope.data);

                            scope.getChatRoomHistory();
                            scope.getChatRecentMessage(scope.data.from);
                            scope.getListChatUser(scope.data.from);

                            scope.isOpenSearch = false;
                            scope.newChatUser.checked = false;
                            scope.txtSearchUsers = "";
                            scope.defaultChecked = null;
                        });

                    }

                };

                scope.$on("focusLastChatHistory", function (scope, elem, attrs) {
                    //elem.parents().animate({scrollTop: elem.parent().prop("scrollHeight")}, 500);
                    elem.parents().animate({scrollTop: elem.parent().prop("scrollHeight")}, 0);
                });

                function iniChatHistory(items) {
                    scope.getChatRecentMessage(scope.data.from);
                    scope.getListChatUser(scope.data.from);

                    if (angular.isObject(items)) {
                        doUpdateChatHistory(items);
                    }
                    else {
                        switch (items.toLowerCase()) {
                            case"new":
                                scope.newChat();
                                break;
                            case "view":
                                setDefaultUserChatSelection();
                                break;
                        }
                    }
                };

                function setDefaultUserChatSelection() {
                    var firstUserofChat = $filter("orderBy")(scope.chatuserslist, "-LastMessageTime")[0];
                    scope.data.to = firstUserofChat.EmployeeCode;
                    scope.currentChatInformation = firstUserofChat;
                }

                function doUpdateChatHistory(items) {
                    scope.isOpenSearch = false;
                    scope.data.to = items.EmployeeCode;
                    scope.currentChatInformation = items;

                    if (items.CountUnreadByPerson > 0) {
                        helper.executeServices(helper.servicesMethod.updateChatHistory, {
                                Chat_From: items.EmployeeCode,
                                Chat_To: scope.ownuser.EmployeeCode,
                                Chat_Status: 'R'
                            })
                            .then(function (resp) {
                                sendUpdateStatusReadMessage({from: items.EmployeeCode, to: scope.ownuser.EmployeeCode});
                                scope.getChatRecentMessage(scope.data.from);
                                scope.getListChatUser(scope.data.from);
                            });
                    }

                    scope.getChatRoomHistory();
                }

            }
        };
    });

